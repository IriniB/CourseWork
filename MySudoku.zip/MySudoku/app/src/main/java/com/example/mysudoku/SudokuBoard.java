package com.example.mysudoku;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class SudokuBoard extends View {
    private final int boardColor;
    private final int cellFillColor;
    private final int cellsHighlightColor;

    private final int letterColor;
    private final int letterColorSolve;

    private final Paint boardColorPaint = new Paint();
    private final Paint cellFillColorPaint = new Paint();
    private final Paint cellsHighlightColorPaint = new Paint();
    private final Paint letterPaint = new Paint();
    private final Rect letterPaintBounds = new Rect();
    private int cellSize;

    private Solver solver;


    public SudokuBoard(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);

        TypedArray a = context.getTheme().obtainStyledAttributes(attrs, R.styleable.SudokuBoard,
                0, 0);

        try {
            boardColor = a.getInteger(R.styleable.SudokuBoard_boardColor, 0);
            cellFillColor = a.getInteger(R.styleable.SudokuBoard_cellFillColor, 0);
            cellsHighlightColor = a.getInteger(R.styleable.SudokuBoard_cellsHighlightColor, 0);
            letterColor = a.getInteger(R.styleable.SudokuBoard_letterColor, 0);
            letterColorSolve = a.getInteger(R.styleable.SudokuBoard_letterColorSolve, 0);
        } finally {
            a.recycle();
        }
    }

    @Override
    protected void onMeasure(int width, int height) {
        super.onMeasure(width, height);
        int dimension = Math.min(this.getMeasuredWidth(), this.getMeasuredHeight());
        cellSize = dimension / 9;

        setMeasuredDimension(dimension, dimension);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        boardColorPaint.setStyle(Paint.Style.STROKE);
        boardColorPaint.setStrokeWidth(16);
        boardColorPaint.setColor(boardColor);
        boardColorPaint.setAntiAlias(true);

        cellFillColorPaint.setStyle(Paint.Style.FILL);
        boardColorPaint.setAntiAlias(true);
        cellFillColorPaint.setColor(cellFillColor);

        cellsHighlightColorPaint.setStyle(Paint.Style.FILL);
        boardColorPaint.setAntiAlias(true);
        cellsHighlightColorPaint.setColor(cellsHighlightColor);

        letterPaint.setStyle(Paint.Style.FILL);
        letterPaint.setAntiAlias(true);
        letterPaint.setColor(letterColor);

        colorCell(canvas, solver.getSelectedRow(), solver.getSelectedColumn());
        canvas.drawRect(0, 0, getWidth(), getHeight(), boardColorPaint);
        drawBoard(canvas);
        drawNumbers(canvas);
        printInitialNumbers(canvas, solver.getData());
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        boolean isValid;

        float x = event.getX();
        float y = event.getY();

        int action = event.getAction();

        if (action == MotionEvent.ACTION_DOWN) {
            solver.setSelectedRow((int)Math.ceil(y/cellSize));
            solver.setSelectedColumn((int)Math.ceil(x/cellSize));
            isValid = true;
        } else {
            isValid = false;
        }

        return isValid;
    }

    private void drawNumbers(Canvas canvas) {
        letterPaint.setTextSize(cellSize);

        letterPaint.setColor(letterColor);
        for (int i = 0; i < 9; ++i) {
            for (int j = 0; j < 9; ++j) {
                if (solver.getBoard()[i][j] != 0) {
                    printNumberOnBoard(canvas, i, j, solver.getBoard()[i][j]);
                }
            }
        }

    }

    private void printInitialNumbers(Canvas canvas, int[][] data) {
        letterPaint.setColor(letterColorSolve);
        for (int i = 0; i < 9; ++i) {
            for (int j = 0; j < 9; ++j) {
                if (data[i][j] != 0) {
                    printNumberOnBoard(canvas, i, j, data[i][j]);
                }
            }
        }
    }

    private void printNumberOnBoard(Canvas canvas, int i, int j, int number) {
        String text = Integer.toString(number);
        float width, height;
        letterPaint.getTextBounds(text, 0, text.length(), letterPaintBounds);
        width = letterPaint.measureText(text);
        height = letterPaintBounds.height();

        canvas.drawText(text, (j*cellSize) + ((cellSize - width)/2),
                (i * cellSize + cellSize) - ((cellSize - height)/ 2),
                letterPaint);
    }

    private void colorCell(Canvas canvas, int row, int column) {
        if (solver.getSelectedColumn() != -1 && solver.getSelectedRow() != -1) {
            canvas.drawRect((column - 1) * cellSize, 0, column * cellSize, cellSize * 9,
                    cellsHighlightColorPaint);
            canvas.drawRect(0, (row - 1) * cellSize, cellSize * 9, row * cellSize,
                    cellsHighlightColorPaint);
            canvas.drawRect((column - 1) * cellSize, (row - 1) * cellSize, column * cellSize, row * cellSize,
                    cellsHighlightColorPaint);
        }
        invalidate();
    }


    private void drawThickLine() {
        boardColorPaint.setStyle(Paint.Style.STROKE);
        boardColorPaint.setStrokeWidth(10);
        boardColorPaint.setColor(boardColor);
    }

    private void drawThinLine() {
        boardColorPaint.setStyle(Paint.Style.STROKE);
        boardColorPaint.setStrokeWidth(4);
        boardColorPaint.setColor(boardColor);
    }

    private void drawBoard(Canvas canvas) {
        for (int column = 0; column < 10; ++column) {
            if (column % 3 == 0) {
                drawThickLine();
            } else {
                drawThinLine();
            }
            canvas.drawLine(cellSize * column, 0,
                    cellSize * column, getWidth(), boardColorPaint);
        }

        for (int row = 0; row < 10; ++row) {
            if (row % 3 == 0) {
                drawThickLine();
            } else {
                drawThinLine();
            }
            canvas.drawLine(0, cellSize * row,
                    getWidth(), cellSize * row, boardColorPaint);
        }
    }

    public void setSolver(Solver solver) {
        this.solver = solver;
    }
}
