package com.example.mysudoku;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import dancingLinks.GameLevel;

public class LevelMenu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_level_menu);
    }

    public void BTNEasyPress(View view) {
        MainActivity.gameLevel = GameLevel.easy;
        Intent intent = new Intent(LevelMenu.this, MainActivity.class);
        startActivity(intent);
    }

    public void BTNNormalPress(View view) {
        MainActivity.gameLevel = GameLevel.middle;
        Intent intent = new Intent(LevelMenu.this, MainActivity.class);
        startActivity(intent);
    }

    public void BTNHardPress(View view) {
        MainActivity.gameLevel = GameLevel.hard;
        Intent intent = new Intent(LevelMenu.this, MainActivity.class);
        startActivity(intent);
    }
}