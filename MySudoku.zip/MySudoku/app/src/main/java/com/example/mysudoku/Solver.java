package com.example.mysudoku;


import android.app.Activity;
import android.content.DialogInterface;
import android.text.SpannableString;
import android.text.util.Linkify;
import android.view.Gravity;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import dancingLinks.GameLevel;
import dancingLinks.Generator;
import dancingLinks.Sudoku;

public class Solver {
    MainActivity mainActivity;
    int[][] board;
    int[][] data;
    //int[][] fullData;
    boolean[][] initialNumbers;

    int selectedRow;
    int selectedColumn;

    Generator generator;
    int filledCounter;

    Solver(MainActivity mainActivity, GameLevel gameLevel) {
        this.mainActivity = mainActivity;
        selectedRow = -1;
        selectedColumn = -1;

        generator = new Generator(gameLevel);
        //fullData = generator.getFullData();
        filledCounter = 81 - generator.generate();
        initialNumbers = new boolean[9][9];

        board = new int[9][9];
        for (int i = 0; i < 9; ++i) {
            for (int j = 0; j < 9; ++j) {
                initialNumbers[i][j] = generator.getData()[i][j] != 0;
                board[i][j] = 0;
            }
        }
        data = generator.getData();
    }

    public void setNumberPos(int number) {
        if (selectedRow != -1 && selectedColumn != -1) {
            if (!initialNumbers[selectedRow - 1][selectedColumn - 1] &&
                    board[selectedRow - 1][selectedColumn - 1] == number) {
                board[selectedRow - 1][selectedColumn - 1] = 0;
                --filledCounter;
            } else if (!initialNumbers[selectedRow - 1][selectedColumn - 1]){
                if (board[selectedRow - 1][selectedColumn - 1] == 0) {
                    ++filledCounter;
                }
                board[selectedRow - 1][selectedColumn - 1] = number;
                if (filledCounter >= 81) {
                    checkForCorrectness();
                }
            }

        }
    }

    public void checkForCorrectness() {
        Sudoku sudoku = new Sudoku();
        int[][] fullData = new int[9][9];
        for (int i = 0; i < 9; ++i) {
            for (int j = 0; j < 9; ++j) {
                if (board[i][j] == 0) {
                    fullData[i][j] = data[i][j];
                } else {
                    fullData[i][j] = board[i][j];
                }
            }
        }
        sudoku.inputData = fullData;
        if (sudoku.game()) {
            mainActivity.createMessage("ПОБЕДА!!!");
        } else {
            mainActivity.createMessage("НЕ ВЕРНО!");
        }
    }



    public int[][] getBoard() {
        return board;
    }

    public int[][] getData() {
        return data;
    }


    public int getSelectedRow() {
        return selectedRow;
    }

    public void setSelectedRow(int selectedRow) {
        this.selectedRow = selectedRow;
    }

    public int getSelectedColumn() {
        return selectedColumn;
    }

    public void setSelectedColumn(int selectedColumn) {
        this.selectedColumn = selectedColumn;
    }
}
