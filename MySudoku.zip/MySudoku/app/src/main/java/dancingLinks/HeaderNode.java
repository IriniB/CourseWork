
package dancingLinks;

public class HeaderNode extends Node {
    HeaderNode leftHeader;
    HeaderNode rightHeader;
}
