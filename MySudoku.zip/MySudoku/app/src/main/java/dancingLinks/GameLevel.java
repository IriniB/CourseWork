package dancingLinks;

public enum GameLevel {
    easy,
    middle,
    hard
}
